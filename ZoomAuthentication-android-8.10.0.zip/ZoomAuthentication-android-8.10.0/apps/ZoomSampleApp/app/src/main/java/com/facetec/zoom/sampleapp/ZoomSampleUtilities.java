package com.facetec.zoom.sampleapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.facetec.zoom.sdk.ZoomCustomization;
import com.facetec.zoom.sdk.ZoomIDScanResult;
import com.facetec.zoom.sdk.ZoomSDK;
import com.facetec.zoom.sdk.ZoomSessionResult;
import java.util.ArrayList;

import ZoomProcessors.Processor;
import ZoomProcessors.ThemeHelpers;
import ZoomProcessors.ZoomGlobalState;

import static com.facetec.zoom.sdk.ZoomSessionStatus.SESSION_COMPLETED_SUCCESSFULLY;

public class ZoomSampleUtilities {

    private ZoomSampleActivity zoomSampleActivity;
    private String currentTheme = "ZoOm Theme";

    public ZoomSampleUtilities(ZoomSampleActivity activity) {
        zoomSampleActivity = activity;
    }

    public void disableAllButtons() {
        zoomSampleActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                zoomSampleActivity.activityMainBinding.enrollButton.setEnabled(false);
                zoomSampleActivity.activityMainBinding.authButton.setEnabled(false);
                zoomSampleActivity.activityMainBinding.livenessCheckButton.setEnabled(false);
                zoomSampleActivity.activityMainBinding.identityCheckButton.setEnabled(false);
                zoomSampleActivity.activityMainBinding.auditTrailImagesButton.setEnabled(false);
                zoomSampleActivity.activityMainBinding.settingsButton.setEnabled(false);
            }
        });
    }

    public void enableAllButtons() {
        zoomSampleActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                zoomSampleActivity.activityMainBinding.enrollButton.setEnabled(true);
                zoomSampleActivity.activityMainBinding.authButton.setEnabled(true);
                zoomSampleActivity.activityMainBinding.livenessCheckButton.setEnabled(true);
                zoomSampleActivity.activityMainBinding.identityCheckButton.setEnabled(true);
                zoomSampleActivity.activityMainBinding.auditTrailImagesButton.setEnabled(true);
                zoomSampleActivity.activityMainBinding.settingsButton.setEnabled(true);
            }
        });
    }

    // Disable buttons to prevent hammering, fade out main interface elements, and shuffle the guidance images.
    public void fadeOutMainUIAndPrepareForZoOm() {
        disableAllButtons();
        zoomSampleActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                zoomSampleActivity.activityMainBinding.contentLayout.animate().alpha(0f).setDuration(600);
                zoomSampleActivity.activityMainBinding.themeTransitionImageView.animate().alpha(1f).setDuration(600);
            }
        });
    }

    public void fadeInMainUI() {
        enableAllButtons();
        zoomSampleActivity.runOnUiThread(new Runnable() {
              @Override
              public void run() {
                  zoomSampleActivity.activityMainBinding.contentLayout.animate().alpha(1f).setDuration(600);
                  zoomSampleActivity.activityMainBinding.themeTransitionImageView.animate().alpha(0f).setDuration(600);
              }
            }
        );
    }

    public void displayStatus(final String statusString) {
        Log.d("ZoOm Log", statusString);
        zoomSampleActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                zoomSampleActivity.activityMainBinding.statusLabel.setText(statusString);
            }
        });
    }

    public void showAuditTrailImages(){
        // Store audit trail images from latest ZoOm Session result for inspection
        ArrayList<Bitmap> auditTrailAndIDScanImages = new ArrayList<Bitmap>();
        if (zoomSampleActivity.latestZoomSessionResult != null) {
            // convert the compressed base64 encoded audit trail images into bitmaps
            for(String compressedBase64EncodedAuditTrailImage: zoomSampleActivity.latestZoomSessionResult.getFaceMetrics().getAuditTrailCompressedBase64()) {
                byte[] decodedString = Base64.decode(compressedBase64EncodedAuditTrailImage, Base64.DEFAULT);
                Bitmap auditTrailImage = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                auditTrailAndIDScanImages.add(auditTrailImage);
            }
        }

        if(zoomSampleActivity.latestZoomIDScanResult != null ){
            if(zoomSampleActivity.latestZoomIDScanResult.getIDScanMetrics() != null) {
                auditTrailAndIDScanImages.add(zoomSampleActivity.latestZoomIDScanResult.getIDScanMetrics().getFrontImages().get(0));
            }
        }

        if(auditTrailAndIDScanImages == null || auditTrailAndIDScanImages.size() <= 0) {
            displayStatus("No audit trail images obtained");
            return;
        }

        for(int i = auditTrailAndIDScanImages.size() - 1; i >= 0; i--) {
            addDismissableImageToInterface(auditTrailAndIDScanImages.get(i));
        }
    }

    public void showResultStatusAndMainUI(boolean isSuccess, ZoomSessionResult zoomSessionResult, ZoomIDScanResult zoomIDScanResult){
        if(isSuccess){
            displayStatus("Success");
        }
        else {
            String statusString = "Unsuccess. ";
            if (zoomIDScanResult != null && zoomIDScanResult.getZoomIDScanStatus() != null){
                statusString += zoomIDScanResult.getZoomIDScanStatus().toString();
            }
            else if(zoomSessionResult != null){
                if (zoomSessionResult.getStatus() == SESSION_COMPLETED_SUCCESSFULLY  && (zoomIDScanResult == null)){
                    statusString += "Session was completed but an unexpected issue occurred during the network request.";
                }
                else {
                    statusString += zoomSessionResult.getStatus().toString();
                }
            }
            else {
                statusString += "zoomSessionResult is null.";
            }
            displayStatus(statusString);
        }
        fadeInMainUI();
    }

    public void handleErrorGettingServerSessionToken() {
        displayStatus("Session could not be started due to an unexpected issue during the network request.");
        fadeInMainUI();
        enableAllButtons();
    }

    public void addDismissableImageToInterface(Bitmap imageBitmap) {
        final Dialog imageDialog = new Dialog(zoomSampleActivity);
        imageDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        imageDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        ImageView imageView = new ImageView(zoomSampleActivity);
        imageView.setImageBitmap(imageBitmap);
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                imageDialog.dismiss();
            }
        });

        // Scale image to better fit device's display.
        DisplayMetrics dm = new DisplayMetrics();
        zoomSampleActivity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        RelativeLayout.LayoutParams layout = new RelativeLayout.LayoutParams(Double.valueOf(dm.widthPixels * 0.5).intValue(), Double.valueOf(dm.heightPixels * 0.5).intValue());
        imageDialog.addContentView(imageView, layout);
        imageDialog.show();
    }

    public void showThemeSelectionMenu() {
        final String[] themes = {"ZoOm Theme", "Pseudo-Fullscreen", "Well-Rounded", "Bitcoin Exchange", "eKYC", "Sample Bank"};

        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(zoomSampleActivity, android.R.style.Theme_Holo_Light));
        builder.setTitle("Select a Theme:");
        builder.setItems(themes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int index) {
                currentTheme = themes[index];
                updateThemeTransitionView();
                ThemeHelpers.setAppTheme(currentTheme);
            }
        });
        builder.show();
    }

    public void updateThemeTransitionView() {
        int transitionViewImage = 0;
        switch (currentTheme) {
            case "ZoOm Theme":
                break;
            case "Pseudo-Fullscreen":
                break;
            case "Well-Rounded":
                transitionViewImage = R.drawable.well_rounded_bg;
                break;
            case "Bitcoin Exchange":
                transitionViewImage = R.drawable.bitcoin_exchange_bg;
                break;
            case "eKYC":
                transitionViewImage = R.drawable.ekyc_bg;
                break;
            case "Sample Bank":
                transitionViewImage = R.drawable.sample_bank_bg;
                break;
            default:
                break;
        }

        zoomSampleActivity.activityMainBinding.themeTransitionImageView.setImageResource(transitionViewImage);
    }

}
