// Welcome to the ZoOm Sample App
//
// This sample demonstrates Initialization, Liveness Check, Enrollment, Authentication, Photo ID Match, Customizing the UX, and Getting Audit Trail Images.
//
// Please use our technical support form to submit questions and issue reports:  https://dev.zoomlogin.com/zoomsdk/#/support

package com.facetec.zoom.sampleapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.facetec.zoom.sampleapp.databinding.ActivityMainBinding;
import com.facetec.zoom.sdk.*;

import ZoomProcessors.AuthenticateProcessor;
import ZoomProcessors.EnrollmentProcessor;
import ZoomProcessors.Processor;
import ZoomProcessors.ZoomGlobalState;
import ZoomProcessors.LivenessCheckProcessor;
import ZoomProcessors.PhotoIDMatchProcessor;

public class ZoomSampleActivity extends Activity {

    public ActivityMainBinding activityMainBinding;
    private ZoomSampleUtilities utils = new ZoomSampleUtilities(this);
    public ZoomSessionResult latestZoomSessionResult;
    public ZoomIDScanResult latestZoomIDScanResult;
    public Processor latestProcessor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        // Initialize ZoOm when the Activity loads and configure the convenience and UI features.
        utils.displayStatus("Initializing...");
        ZoomSDK.initialize(
                this,
                ZoomGlobalState.DeviceLicenseKeyIdentifier,
                ZoomGlobalState.PublicFaceMapEncryptionKey,
                new ZoomSDK.InitializeCallback() {
                    @Override
                    public void onCompletion(final boolean successful) {
                        utils.displayStatus(ZoomSDK.getStatus(ZoomSampleActivity.this).toString());
                        if(successful) {
                            utils.enableAllButtons();
                        }
                    }
                }
        );

        // If the screen size is small, reduce ZoOm and FaceTec Logo
        if(getResources().getConfiguration().screenHeightDp < 500) {
            activityMainBinding.zoomLogo.setScaleX(0.6f);
            activityMainBinding.zoomLogo.setScaleY(0.6f);
            activityMainBinding.facetecLogo.setScaleX(0.6f);
            activityMainBinding.facetecLogo.setScaleY(0.6f);

            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) activityMainBinding.zoomLogo.getLayoutParams();
            params.setMargins(0, 0, 0, 0);
        }
    }

    // Perform Liveness Check.
    public void onLivenessCheckPressed(View v) {
        utils.fadeOutMainUIAndPrepareForZoOm();
        latestProcessor = new LivenessCheckProcessor( this, sessionTokenErrorCallback);
    }

    // Perform Enrollment, generating a username each time to guarantee uniqueness.
    public void onEnrollUserPressed(View v) {
        utils.fadeOutMainUIAndPrepareForZoOm();
        latestProcessor = new EnrollmentProcessor( this, sessionTokenErrorCallback);
    }

    // Perform Authentication, using the username from Enrollment.
    public void onAuthenticateUserPressed(View v) {
        if(!ZoomGlobalState.isRandomUsernameEnrolled){
            utils.displayStatus("Please enroll first before trying authentication.");
            return;
        }

        utils.fadeOutMainUIAndPrepareForZoOm();
        latestProcessor  = new AuthenticateProcessor(this, sessionTokenErrorCallback);
    }

    // Perform Photo ID Match, generating a username each time to guarantee uniqueness.
    public void onPhotoIDMatchPressed(View view) {
        utils.fadeOutMainUIAndPrepareForZoOm();
        latestProcessor = new PhotoIDMatchProcessor(this, sessionTokenErrorCallback);
    }

    // Display audit trail images captured from user's last ZoOm Session (if available).
    public void onViewAuditTrailPressed(View view) {
        utils.showAuditTrailImages();
    }

    // Present settings action sheet, allowing user to select a new app theme (pre-made ZoomCustomization configuration).
    public void onThemeSelectionPressed(View view) {
        utils.showThemeSelectionMenu();
    }

    // The final callback ZoOm SDK calls when done with everything.
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Save results
        if(data != null) {
            ZoomSessionResult zoomSessionResult = ZoomSessionActivity.getZoomSessionResultFromActivityResult(data);
            this.latestZoomSessionResult = zoomSessionResult;

            ZoomIDScanResult zoomIDScanResult = ZoomSessionActivity.getZoomIDScanResultFromActivityResult(data);
            this.latestZoomIDScanResult = zoomIDScanResult;
            // Show the final result and transition back into the main interface.
            utils.showResultStatusAndMainUI(this.latestProcessor.isSuccess(), zoomSessionResult, zoomIDScanResult );
        }
    }

    // Handle error retrieving the Session Token from the server
    Processor.SessionTokenErrorCallback sessionTokenErrorCallback = new Processor.SessionTokenErrorCallback() {
        @Override
        public void onError() {
            utils.handleErrorGettingServerSessionToken();
        }
    };
}